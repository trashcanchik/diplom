<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'config.php';
$user_id = (int) $_SESSION['user_id'];

// Проверяем, является ли текущий пользователь администратором
$stmtUser = $mysqli->prepare('SELECT is_admin FROM users WHERE id = ?');
if (!$stmtUser) {
    die('Ошибка подготовки запроса: ' . $mysqli->error);
}
$stmtUser->bind_param('i', $user_id);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$userRow = $resultUser->fetch_assoc();

if (!$userRow || (int)$userRow['is_admin'] !== 1) {
    http_response_code(403);
    echo '<h2>Доступ запрещён</h2><p>У вас нет прав для просмотра этой страницы.</p>';
    exit;
}

// Если админ, получаем все заявления с именами пользователей
$sql = '
    SELECT a.id, a.fio, a.passport_series, a.passport_number, a.snils,
           a.certificate_type, a.certificate_avg_score, a.exam_oge_score, a.exam_ege_score,
           a.grades_completed, a.specialty, a.created_at, u.username
    FROM applications AS a
    JOIN users AS u ON a.user_id = u.id
    ORDER BY a.created_at DESC
';
$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    die('Ошибка подготовки запроса: ' . $mysqli->error);
}
$stmt->execute();
$result = $stmt->get_result();
$allApps = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Список всех заявлений (админ)</title>
</head>
<body>
    <h2>Все заявления</h2>
    <?php if (empty($allApps)): ?>
        <p>Пока нет ни одного заявления.</p>
    <?php else: ?>
        <table border="1" cellpadding="5" cellspacing="0">
            <tr>
                <th>№</th>
                <th>Дата подачи</th>
                <th>Пользователь</th>
                <th>ФИО</th>
                <th>Тип аттестата</th>
                <th>Средний балл</th>
                <th>Баллы</th>
                <th>Классы</th>
                <th>Специальность</th>
                <th>Статус</th>
            </tr>
            <?php foreach ($allApps as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['date_submitted'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= htmlspecialchars($row['fio']) ?></td>
                    <td><?= $row['certificate_type'] === '9' ? '9 классов' : '11 классов' ?></td>
                    <td><?= htmlspecialchars($row['certificate_avg_score']) ?></td>
                    <td>
                        <?php if ($row['certificate_type'] === '9'): ?>
                            ОГЭ: <?= htmlspecialchars($row['exam_oge_score']) ?>
                        <?php else: ?>
                            ЕГЭ: <?= htmlspecialchars($row['exam_ege_score']) ?>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['grades_completed']) ?></td>
                    <td><?= htmlspecialchars($row['specialty']) ?></td>
                    <td>На рассмотрении</td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>
