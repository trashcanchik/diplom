// application-ajax.js
document.addEventListener('DOMContentLoaded', () => {
        const form = document.getElementById('applicationForm');
        if (!form) return;
    
        form.addEventListener('submit', function(e) {
        e.preventDefault(); // отменяем обычный сабмит
    
        // Отключаем кнопку, чтобы пользователь не нажал дважды
        const btn = document.getElementById('submitAppBtn');
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Пожалуйста, подождите…';
        }
    
        // Собираем данные формы
        const formData = new FormData(form);
    
        // Отправляем на сервер
        fetch('submit_application.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) throw new Error('Сервер вернул код ' + response.status);
            return response.text(); // мы ничего не парсим, просто ждём «ок»
        })
        .then(html => {
            // 2.1. Скрываем форму (модалку с формой)
            const formOverlay = document.getElementById('formModalOverlay');
            if (formOverlay) {
            formOverlay.style.display = 'none';
            document.body.style.overflow = '';
            }
            form.reset(); // очистим форму
    
            // 2.2. Открываем «Мои заявления» и автоматически подгружаем туда свежую таблицу
            showAppsModal(); // это ваша функция из script2.js
        })
        .catch(err => {
            alert('Ошибка при отправке: ' + err.message);
        })
        .finally(() => {
            // Разблокируем кнопку
            if (btn) {
            btn.disabled = false;
            btn.textContent = 'Отправить заявление';
          }
  
          // 3.1) Показываем модалку «Мои заявления»
          if (typeof showMyApplicationsModal === 'function') {
            showMyApplicationsModal();
          }
  
          // 3.2) Если есть div для сообщения об успехе, показываем внутри него текст
          if (successDiv) {
            successDiv.textContent = '✅ Заявление успешно отправлено!';
            successDiv.classList.remove('hidden');
  
            // через 2 секунды скрываем сообщение и очищаем его текст
            setTimeout(function() {
              successDiv.classList.add('hidden');
              successDiv.textContent = '';
            }, 2000);
          }
        })
        .catch(err => {
          // 4) Если в процессе отправки что-то пошло не так — сообщаем об ошибке
          alert('Ошибка при отправке: ' + err.message);
        })
        .finally(() => {
          // 5) В любое случае (успех или ошибка) восстанавливаем кнопку
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Отправить заявление';
          }
          // сбрасываем форму (если нужно)
          form.reset();
        });
    });
  });
  
  